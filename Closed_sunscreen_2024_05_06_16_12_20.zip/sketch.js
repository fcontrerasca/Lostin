let img;
let hiraganaChars = [];
let pixelMatrix = [];
let staticPixels = [];
let staticCounter_L = 0;
let staticCounter_O = 0;
let staticCounter_S = 0;
let staticCounter_T = 0;
let staticCounter_I = 0;
let staticCounter_N = 0;
let staticCounter_T2 = 0;
let staticCounter_R = 0;
let staticCounter_A = 0;
let staticCounter_N2 = 0;
let staticCounter_S2 = 0;
let staticCounter_L2 = 0;
let staticCounter_A2 = 0;
let staticCounter_T3 = 0;
let staticCounter_I2 = 0;
let staticCounter_O2 = 0;
let staticCounter_N3 = 0;




function preload() {
    img = loadImage('ScarlettJ.jpg');
}

function setup() {
    createCanvas(700, 700);
    img.resize(70, 70); // Ajusta el tamaño de la imagen a 40x40
    img.loadPixels();

    // Crea un array con los caracteres hiragana
    for (let i = 0x3041; i <= 0x3096; i++) {
        hiraganaChars.push(String.fromCharCode(i));
    }

    // Inicializa la matriz de píxeles
    for (let y = 0; y < img.height; y++) {
        let pixelRow = [];
        for (let x = 0; x < img.width; x++) {
            let index = (x + y * img.width) * 4;
            let brightness = (img.pixels[index] + img.pixels[index + 1] + img.pixels[index + 2]) / 3;
            if (brightness < 50) { // Si el píxel es lo suficientemente oscuro
                pixelRow.push(hiraganaChars[Math.floor(random(hiraganaChars.length))]); // Inicialmente, cada píxel tiene un carácter aleatorio
            } else {
                pixelRow.push(''); // Si el píxel no es lo suficientemente oscuro, deja el carácter vacío
            }
        }
        pixelMatrix.push(pixelRow);
    }

    // Encuentra píxeles negros para las letras estáticas
    for (let y = 0; y < pixelMatrix.length; y++) {
        for (let x = 0; x < pixelMatrix[y].length; x++) {
            if (pixelMatrix[y][x] !== '') {
                staticPixels.push(createVector(x, y)); // Agrega los píxeles negros a la lista de píxeles estáticos
            }
        }
    }

    // Escoge píxeles aleatorios para las letras estáticas
  
  staticPixel_L = createVector(18, 39);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 18 && pixel.y === 39), 1);
  
  staticPixel_O = createVector(26, 38);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 26 && pixel.y === 38), 1);
  
   staticPixel_S = createVector(19, 27);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 19 && pixel.y === 27), 1);
  
   staticPixel_T = createVector(24, 31);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 24 && pixel.y === 31), 1);
  
   staticPixel_I = createVector(45, 20);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 13 && pixel.y === 10), 1);
  
   staticPixel_N = createVector(50, 35);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 29 && pixel.y === 20), 1);
  
  
  
  
  //Pixeles con posición para letras estáticas
  
  
  
    staticPixel_T2 = createVector(9, 59);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 9 && pixel.y === 59), 1);
  
  staticPixel_R = createVector(17, 49);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 15 && pixel.y === 30), 1);
  
  staticPixel_A = createVector(25, 54);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 20 && pixel.y === 50), 1);
  
  staticPixel_N2 = createVector(24, 43);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 21 && pixel.y === 29), 1);
  
  staticPixel_S2 = createVector(33, 48);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 23 && pixel.y === 34), 1);
  
  staticPixel_L2 = createVector(30, 41);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 25 && pixel.y === 27), 1);
  
  staticPixel_A2 = createVector(44, 35);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 26 && pixel.y === 30), 1);
  
  staticPixel_T3 = createVector(37, 40);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 22 && pixel.y === 27), 1);
  
  staticPixel_I2 = createVector(44, 47);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 23 && pixel.y === 27), 1);
  
  staticPixel_O2 = createVector(38, 52);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 24 && pixel.y === 27), 1);
  
  staticPixel_N3 = createVector(54, 54);
    staticPixels.splice(staticPixels.findIndex(pixel => pixel.x === 25 && pixel.y === 27), 1);
  
 setInterval(changeCharacters, 100); // Cambia las letras cada décimo de segundo
}

function draw() {
    let r = 128; // Componente rojo en RGB
    let g = 146; // Componente verde en RGB
    let b = 187; // Componente azul en RGB
    background(r, g, b); // Establece el color de fondo en lila (RGB 128, 146, 187)
    textSize(10); // Establece el tamaño del texto
    textStyle(NORMAL); // Establece el estilo de texto
    textFont('Helvetica Neue'); // Establece la fuente personalizada

    // Dibuja la matriz de píxeles
    for (let y = 0; y < pixelMatrix.length; y++) {
        for (let x = 0; x < pixelMatrix[y].length; x++) {
            let character = pixelMatrix[y][x];
            if (character !== '') {
                if (character === 'L' || character === 'O' || character === 'S' || character === 'T' || character === 'I' || character === 'N' ||  character === 'T2' ||  character === 'R'  ||  character === 'A'  ||  character === 'N2' ||  character === 'S2' ||  character === 'L2' ||  character === 'A2' ||  character === 'T3' ||  character === 'I2' ||  character === 'O2' ||  character === 'N3')  {
                    fill(255); // Establece el color de relleno en blanco para las letras L, O, S y T
                } else {
                    fill(0); // Establece el color de relleno en negro para los demás caracteres
                }
                text(character, x * 10, y * 10); // Dibuja el carácter en la posición correspondiente
            }
        }
    }
}

function changeCharacters() {
    for (let y = 0; y < pixelMatrix.length; y++) {
        for (let x = 0; x < pixelMatrix[y].length; x++) {
            let brightness = getBrightness(img, x, y);
            if (brightness < 50) { // Si el píxel es lo suficientemente oscuro
                let currentIndex = hiraganaChars.indexOf(pixelMatrix[y][x]);
                let nextIndex = (currentIndex + 1) % hiraganaChars.length;
                // Para la letra L
                if (x === staticPixel_L.x && y === staticPixel_L.y && staticCounter_L >= 39) {
                    pixelMatrix[y][x] = 'L'; // Establece la letra L en el píxel estático después de 14 cambios
                }
                // Para la letra O
                else if (x === staticPixel_O.x && y === staticPixel_O.y && staticCounter_O >= 42) {
                    pixelMatrix[y][x] = 'O'; // Establece la letra O en el píxel estático después de 20 cambios
                }
              
                // Para la letra S
                else if (x === staticPixel_S.x && y === staticPixel_S.y && staticCounter_S >= 45) {
                    pixelMatrix[y][x] = 'S'; // Establece la letra S en el píxel estático después de 26 cambios
                }
              
                // Para la letra T
                else if (x === staticPixel_T.x && y === staticPixel_T.y && staticCounter_T >= 48) {
                    pixelMatrix[y][x] = 'T'; // Establece la letra T en el píxel estático después de 34 cambios
                } 
              
               // Para la letra I
                else if (x === staticPixel_I.x && y === staticPixel_I.y && staticCounter_I >= 51) {
                    pixelMatrix[y][x] = 'I'; // Establece la letra T en el píxel estático después de 60 cambios
                } 
              
               // Para la letra N
                else if (x === staticPixel_N.x && y === staticPixel_N.y && staticCounter_N >= 55) {
                    pixelMatrix[y][x] = 'N'; // Establece la letra T en el píxel estático después de 60 cambios
                } 
              
              // Para la letra T02
              else if (x === staticPixel_T2.x && y === staticPixel_T2.y && staticCounter_T2 >= 58) {
    pixelMatrix[y][x] = 'T'; // Establece la letra T en el píxel estático después de 60 cambios
                }
              
               // Para la letra R
              else if (x === staticPixel_R.x && y === staticPixel_R.y && staticCounter_R >= 61) {
    pixelMatrix[y][x] = 'R'; // Establece la letra R en el píxel estático después de 67 cambios
                }
              
               // Para la letra A
              else if (x === staticPixel_A.x && y === staticPixel_A.y && staticCounter_A >= 63) {
    pixelMatrix[y][x] = 'A'; // Establece la letra A en el píxel estático después de 72 cambios
                }
              
               // Para la letra N2
              else if (x === staticPixel_N2.x && y === staticPixel_N2.y && staticCounter_N2 >= 66) {
    pixelMatrix[y][x] = 'N'; // Establece la letra N2 en el píxel estático después de 78 cambios
                }
              
               // Para la letra S2
              else if (x === staticPixel_S2.x && y === staticPixel_S2.y && staticCounter_S2 >= 69) {
    pixelMatrix[y][x] = 'S'; // Establece la letra S2 en el píxel estático después de 84 cambios
                }
              
              
               // Para la letra L2
              else if (x === staticPixel_L2.x && y === staticPixel_L2.y && staticCounter_L2 >= 72) {
    pixelMatrix[y][x] = 'L'; // Establece la letra L2 en el píxel estático después de 90 cambios
                }
              
              
               // Para la letra A2
              else if (x === staticPixel_A2.x && y === staticPixel_A2.y && staticCounter_A2 >= 75) {
    pixelMatrix[y][x] = 'A'; // Establece la letra A2 en el píxel estático después de 96 cambios
                }
              
              
               // Para la letra T3
              else if (x === staticPixel_T3.x && y === staticPixel_T3.y && staticCounter_T3 >= 78) {
    pixelMatrix[y][x] = 'T'; // Establece la letra T3 en el píxel estático después de 96 cambios
                }
              
              
               // Para la letra I2
              else if (x === staticPixel_I2.x && y === staticPixel_I2.y && staticCounter_I2 >= 81) {
    pixelMatrix[y][x] = 'I'; // Establece la letra I2 en el píxel estático después de 98 cambios
                }
              
              
               // Para la letra O2
              else if (x === staticPixel_O2.x && y === staticPixel_O2.y && staticCounter_O2 >= 84) {
    pixelMatrix[y][x] = 'O'; // Establece la letra O2 en el píxel estático después de 100 cambios
                }
              
               // Para la letra N3
              else if (x === staticPixel_N3.x && y === staticPixel_N3.y && staticCounter_N3 >= 87) {
    pixelMatrix[y][x] = 'N'; // Establece la letra N3 en el píxel estático después de 102 cambios
                }
              
          else {
                    pixelMatrix[y][x] = hiraganaChars[nextIndex]; // Cambia el carácter
                }
            }
        }
    }
    staticCounter_L++;
    staticCounter_O++;
    staticCounter_S++;
    staticCounter_T++;
    staticCounter_I++;
    staticCounter_N++;
    staticCounter_T2++;
    staticCounter_R++;
    staticCounter_A++;
    staticCounter_N2++;
    staticCounter_S2++;
    staticCounter_L2++;
    staticCounter_A2++;
    staticCounter_T3++;
    staticCounter_I2++;
    staticCounter_O2++;
    staticCounter_N3++;
}

function getBrightness(image, x, y) {
    let index = (x + y * img.width) * 4;
    return (image.pixels[index] + image.pixels[index + 1] + image.pixels[index + 2]) / 3;
}

function keyPressed(){
  if (key == 's') {
    saveGif ('animation.gif', 25);
    
  }
  
}